/*
 * Copyright 2008-2009 Maxim Starodubcev <starodubcevmax@gmail.com>
 * Copyright 2009 Sergey Rudchenko <rudchenkos@gmail.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor,
 * Boston, MA  02110-1301  USA
 */

#define LOW_FREQ    1
#define HIGH_FREQ   2
#define BANDPASS    3
#define BAND_REJECT 4

#include <stdio.h>
#include <locale.h>
#include <libintl.h>

#define _(x) gettext(x)

int main() 
{
    setlocale(LC_ALL, ""); 
    bindtextdomain("ffilter", INSTALL_PREFIX "/locale");
    textdomain("ffilter");

    printf("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n");
    printf(_("+ This is a program for calculating the electronic filters.+\n"));
    printf("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n");  
     
    int t;

    printf(_("Enter the type of filter\n1:LP\n2:HP\n3:BANDPASS\n4:BAND-REJECT\n:"));
    scanf("%d", &t);
    
    if (t == LOW_FREQ || t == HIGH_FREQ)
    {
	double f, r, L, C;
	int z;

	printf(_("Enter cut-off frequency in kHz\n:"));
	scanf("%lf", &f);

	printf(_("Enter load resistance in ohms\n:"));
	scanf("%lf", &r);

	if (t == LOW_FREQ)
        {
	    L = (0.32 * r) / f;
	    C = 320 / (f * r);
        }  

	if (t == HIGH_FREQ)
        {
	    L = (0.08 * r) / f;
	    C = 80 / (r * f);
        }

	printf(_("Enter the type of topology\n1:L\n2:T\n3:Pi\n:"));
	scanf("%d", &z);
    
	if (z == 1 && t == LOW_FREQ)
        {
	    printf("     L          \n");
	    printf("o---^^^----+---o\n");
	    printf("           |    \n");
	    printf("          === C \n");
	    printf("           |    \n");
	    printf("o----------+---o\n");
	    printf("L=%10.3lf mH\nC=%10.3lf uF\n",L/2,C/2);
        }

	if (z == 2 && t == LOW_FREQ)
        {
	    printf("    L         L    \n");
	    printf("o--^^^---+---^^^--o\n");
	    printf("         |         \n");
	    printf("        === C      \n");
	    printf("         |         \n");
	    printf("o--------+--------o\n");
	    printf("L=%10.3lf mH\nC=%10.3lf uF\n",L/2,C);
        }

	if (z == 3 && t == LOW_FREQ)
        {
	    printf("         L         \n");
	    printf("o---+---^^^---+---o\n");
	    printf("    |         |    \n");
	    printf("   === C     === C \n");
	    printf("    |         |    \n");
	    printf("o---+---------+---o\n");
	    printf("L=%10.3lf mH\nC=%10.3lf uF\n",L,C/2);
        }

	if (z == 1 && t == HIGH_FREQ)
        {
	    printf("     C          \n");
	    printf("o----||----+---o\n");
	    printf("           |    \n");
	    printf("           )    \n");
	    printf("           ) L  \n");
	    printf("           )    \n");
	    printf("           |    \n");
	    printf("o----------+---o\n");
	    printf("L=%10.3lf mH\nC=%10.3lf uF\n",L * 2,C * 2);
        }

	if(z == 2 && t == HIGH_FREQ)
        {
	    printf("   C        C    \n");
	    printf("o--||---+---||--o\n");
	    printf("        |        \n");
	    printf("        )        \n");
	    printf("        ) L      \n");
	    printf("        )        \n");
	    printf("        |        \n");
	    printf("o-------+-------o\n");
	    printf("L=%10.3lf mH\nC=%10.3lf uF\n",L,C * 2);
        }

	if (z == 3 && t == HIGH_FREQ)
        {
            printf("        C         \n");
	    printf("o---+---||---+---o\n");
	    printf("    |        |    \n");
	    printf("    )        )    \n");
	    printf("    ) L      ) L \n");
	    printf("    )        )    \n");
	    printf("    |        |    \n");
	    printf("o---+--------+---o\n");
	    printf("L=%10.3lf mH\nC=%10.3lf uF\n",L * 2,C);
        }
    }

    if (t == BANDPASS || t == BAND_REJECT)
    {
	double f1, f2, r, L1, L2, C1, C2;
	int z;
	
	printf(_("Enter the first cut-off frequency in kHz\n:"));
	scanf("%lf", &f1);

	printf(_("Enter the second cut-off frequency in kHz\n:"));
	scanf("%lf", &f2);

	printf(_("Enter load resistance in ohms\n:"));
	scanf("%lf", &r);

	if (t == BANDPASS)
        {
	    L1 = (0.32 * r) / (f2 - f1);
	    L2 = (0.08 * (f2 - f1) * r) / (f1 * f2);
	    C1 = (80 * (f2 - f1)) / (r * f1 * f2);
	    C2 = 320 / (r * (f2 - f1));
        }

	if (t == BAND_REJECT)
        {
	    L1 = (0.32 * r * (f2 - f1)) / (f1 * f2);
	    L2 = (0.08 * r) / (f2 - f1);
	    C1 = 80 / ((f2 - f1) * r);
	    C2 = (320 * (f2 - f1)) / (r * f1 * f2);
        }
	
	printf(_("Enter the type of topology\n1:L\n2:T\n3:Pi\n:"));
	scanf("%d", &z);

        if (z == 1 && t == BANDPASS)
        {
	    printf("    L1      C1                 \n");
	    printf("o---^^^-----||------+---------o\n");
	    printf("                  __|_         \n");
	    printf("                 |    )        \n");
	    printf("            C2  ===   ) L2     \n");
	    printf("                 |____)        \n");
	    printf("                    |          \n");
	    printf("o-------------------+---------o\n");
	    printf("L1=%10.3lf mH\nL2=%10.3lf mH\nC1=%10.3lf uF\nC2=%10.3lf uF\n",L1 / 2,L2 * 2,C1 * 2,C2 / 2);
        }

	if (z == 2 && t == BANDPASS)
        {
	    printf("    L1    C1       C1   L1     \n");
	    printf("o---^^^---||---+---||---^^^---o\n");
	    printf("             __|_              \n");
	    printf("            |    )             \n");
	    printf("       C2  ===   ) L2          \n");
	    printf("            |____)             \n");
	    printf("               |               \n");
	    printf("o--------------+--------------o\n");
	    printf("L1=%10.3lf mH\nL2=%10.3lf mH\nC1=%10.3lf uF\nC2=%10.3lf uF\n",L1 / 2,L2,C1 * 2,C2);
        }

	if (z == 3 && t == BANDPASS)
        {
	    printf("            L1    C1           \n");
	    printf("o------+----^^^---||----+-----o\n");
	    printf("     __|_             __|_     \n");
	    printf("    |    )           |    )    \n");
	    printf("C2 ===   ) L2    C2 ===   ) L2 \n");
	    printf("    |____)           |____)    \n");
	    printf("       |                |      \n");
	    printf("o------+----------------+-----o\n");
	    printf("L1=%10.3lf mH\nL2=%10.3lf mH\nC1=%10.3lf uF\nC2=%10.3lf uF\n",L1,L2 * 2,C1,C2 / 2);
        }

	if (z == 1 && t == BAND_REJECT)
        {   
	    printf("       L1                           \n");
	    printf("    +--^^^--+                       \n");
	    printf("o---|       |---------+------------o\n");
	    printf("    +--||---+         |             \n");
	    printf("       C1             )             \n");
	    printf("                      )  L2         \n");
	    printf("                      )             \n");
	    printf("                      |             \n");
	    printf("                     === C2         \n");
	    printf("                      |             \n");
	    printf("o---------------------+------------o\n");
	    printf("L1=%10.3lf mH\nL2=%10.3lf mH\nC1=%10.3lf uF\nC2=%10.3lf uF\n",L1 / 2,L2 * 2,C1 * 2,C2 / 2);
        }

	if (z == 2 && t == BAND_REJECT)
        {
	    printf("       L1                   L1        \n");
	    printf("    +--^^^--+            +--^^^--+    \n");
	    printf("o---|       |-----+------|       |---o\n");
	    printf("    +--||---+     |      +--||---+    \n");
	    printf("       C1         )         C1        \n");
	    printf("                  )  L2               \n");
	    printf("                  )                   \n");
	    printf("                  |                   \n");
	    printf("                 === C2               \n");
	    printf("                  |                   \n");
	    printf("o-----------------+------------------o\n");
	    printf("L1=%10.3lf mH\nL2=%10.3lf mH\nC1=%10.3lf uF\nC2=%10.3lf uF\n",L1 / 2,L2,C1 * 2,C2);
        }

	if (z == 3 && t == BAND_REJECT)
        {
	    printf("                L1                   \n");
	    printf("             +--^^^--+               \n");
	    printf("o------+-----|       |-----+--------o\n");
	    printf("       |     +--||---+     |         \n");
	    printf("       )        C1         )         \n");
	    printf("       ) L2                )  L2     \n");
	    printf("       )                   )         \n");
	    printf("       |                   |         \n");
	    printf("      === C2              === C2     \n");
	    printf("       |                   |         \n");
	    printf("o------+-------------------+--------o\n");
	    printf("L1=%10.3lf mH\nL2=%10.3lf mH\nC1=%10.3lf uF\nC2=%10.3lf uF\n",L1,L2 * 2,C1,C2 / 2);
        }
    }

    return 0;
}
