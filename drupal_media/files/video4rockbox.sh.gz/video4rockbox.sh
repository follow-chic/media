#/bin/sh

DEV=$( ls -l /dev/disk/by-id/ | grep 'usb-SanDisk_Sansa_e2' | grep -Eo '...1$' )

if ( test "$DEV"1 != "1" ) then

    if ( mount | grep -E "$DEV" ) then
	SRCFILENAME=$( kdialog --separate-output --multiple --getopenfilename ~/ '*.*' | sed -r 's/ /\*\&\#\%\$\@\~SpAsE\~\@\$\%\#\&\*\!601837aefdc/g' )
	MOUNTPOINT=$( mount | grep -E "$DEV" | sed -r "s/\stype\svfat.*$//g;s/^\/dev\/$DEV\son\s//g" )
	if (test "$SRCFILENAME"1 != "1") then
	RESOLUTION=$( kdialog --menu 'Выберите соотношение сторон.' 166 "4/3" 137 "16/10" 124 "16/9" )
	QUALITYVIDEO=`kdialog --combobox 'Выберите битрейт видео, киб/с.' 100 150 200 250 300 350 400 450 500 550 600 650 700 750 800`
	    
	    if (test "$QUALITYVIDEO"1 != "1") then
		QUALITYAUDIO=`kdialog --combobox 'Выберите битрейт аудио, киб/с.' 56 64 80 96 112 128 160 192 224`

		if (test "$QUALITYAUDIO"1 != "1") then

		    for FILENAME in $SRCFILENAME
		    do
			FILE=$( echo $FILENAME | sed -r 's/\*\&\#\%\$\@\~SpAsE\~\@\$\%\#\&\*\!601837aefdc/ /g' )
			SAVEFILENAME=$( echo $FILE | sed -r 's/....$/.mpg/;s/^.*\///g' )
			echo 'Кодирую файл' $FILE
			if ( `ffmpeg -i "$FILE" -s 220x$RESOLUTION -vcodec mpeg2video -b  "$QUALITYVIDEO"k  -an -pass 1 "/tmp/$SAVEFILENAME"` ) then
			    yes | ffmpeg -i "$FILE" -s 220x$RESOLUTION -vcodec mpeg2video -b  "$QUALITYVIDEO"k -ab "$QUALITYAUDIO"k -ac 2 -ar 44100 -acodec libmp3lame -pass 1 "/tmp/$SAVEFILENAME"
			    if ( mv "/tmp/$SAVEFILENAME" "$MOUNTPOINT/VIDEO/$SAVEFILENAME" ) then
				 kdialog --msgbox 'Кодирование завершено!'
			    else
				kdialog --error 'Ошибка перемещения!'
			    fi
			else
			    kdialog --error 'Ошибка перекодирования!\nОбычно это означает что ffmpeg не установлен.'
			fi

		    done

		  
		
		else
		    kdialog --error 'Неправильный битрейт аудио!'
		fi

	    else
		kdialog --error 'Неправильный битрейт видео!'
	    fi
	
	else
	    kdialog --error 'Неправильное имя исходного файла!'
	fi

    else
	kdialog --error "Ваш плеер не примонтирован!"
    fi

else
    kdialog --error "Ваш плеер не подключен!"
fi