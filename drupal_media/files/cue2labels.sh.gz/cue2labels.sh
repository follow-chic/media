#! /bin/bash

CUE_FILE_NAME=$1

if ( test -f labels.txt )
    then
    rm labels.txt
fi
    
    #Get source file name
FILE_NAME=$( cat "$CUE_FILE_NAME" | grep -E '^\<FILE\>' |\
grep -Eo '\".*\"' | sed -r 's/^.//g;s/.$//g' )

    #Get Cuesheet
CUE_TMP=$( sed -n '/\<INDEX\>/p' "$CUE_FILE_NAME" |\
grep -Eo '..:..:..' | sed '1 d' && sox --i "$FILE_NAME" |\
grep -E '\<Duration\>' | grep -Eo '[0-9]{2}:[0-9]{2}\.[0-9]{2}' |\
sed -r 's/\./:/g;s/\<00:00:00\>//g')
    
    #Convert cue to labels
LINE_NUMBER=1
LABEL_1=0.000000
for LINE_CUE in $CUE_TMP
    do
    NUMBER_OF_TRACK=$( echo 0$LINE_NUMBER | grep -Eo '..$' )
    MINUTES=$( echo $LINE_CUE | sed -r 's/......$//g')
    SECONDS=$( echo $LINE_CUE | sed -r 's/^...|...$//g' )
    FRAMES=$( echo $LINE_CUE | sed -r 's/^......//g' )
    TITLE=$( cat "$CUE_FILE_NAME" | grep -E '\<TITLE\>' | grep -Eo '\".*\"' |\
    sed '1 d' | sed -nr "s/^.//g;$LINE_NUMBER s/.$//gp" )
    LABEL_SECONDS=$( echo "($MINUTES*60)+$SECONDS" | bc )
    LABEL_REMAINDER=$( echo "$FRAMES*1.35" | bc | sed -r 's/\.//' )
    LABEL_2=$( echo $LABEL_SECONDS.$LABEL_REMAINDER"000000" |\
    grep -Eo '[0-9]*\.......' | sed -r 's/\./,/g' )
    echo $LABEL_1 $LABEL_2 $NUMBER_OF_TRACK-$TITLE >> labels.txt
    LABEL_1=$LABEL_2
    LINE_NUMBER=$(($LINE_NUMBER+1))
done

exit 0





